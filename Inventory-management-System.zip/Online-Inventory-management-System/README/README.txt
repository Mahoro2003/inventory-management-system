this inventory management system
that contain three panel
1st for HOP
2nd fro COORDINATOR
3rd for LOGISTIC OFFICER
PASSWORDS  AND NAMEs THAT WILL  ENABLE TO LOG IN WITH DIFFERENT USER :
hod:123, coordinator:123,logistic:123 
